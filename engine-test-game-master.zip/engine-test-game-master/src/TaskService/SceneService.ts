class SenceService extends EventEmitter{


    public notify(){

    }
}


